# Create Players

class Player:

    def __init__(self, name, position=0):
        self.name = name.upper()
        self.position = position
